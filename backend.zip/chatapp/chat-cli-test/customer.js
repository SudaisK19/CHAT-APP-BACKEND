// customer.js
const io      = require('socket.io-client');
const readline= require('readline');

// ─── CONFIGURE ───
const SOCKET_URL    = 'http://localhost:5000';
const CHAT_ID       = process.env.CHAT_ID;
const CUSTOMER_ID   = process.env.CUSTOMER_ID;
const CUSTOMER_JWT  = process.env.CUSTOMER_JWT;
// ──────────────────

if (!CHAT_ID || !CUSTOMER_ID || !CUSTOMER_JWT) {
  console.error('❌ Missing one of CHAT_ID, CUSTOMER_ID or CUSTOMER_JWT env vars');
  process.exit(1);
}

const socket = io(SOCKET_URL, {
  auth: { token: CUSTOMER_JWT }
});

socket.on('connect', () => {
  console.log('✅ Customer connected:', socket.id);
  socket.emit('join_chat', CHAT_ID);
});

socket.on('new_message', msg => {
  if (msg.senderId !== CUSTOMER_ID) {
    console.log('\x1b[32mAdmin:\x1b[0m', msg.content);
  }
});

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
rl.setPrompt('You: ');
rl.prompt();
rl.on('line', line => {
  socket.emit('send_message', {
    chatId:    CHAT_ID,
    senderId:  CUSTOMER_ID,
    content:   line.trim(),
    timestamp: Date.now(),
  });
  rl.prompt();
});
